// ====================================================================
//                     UNIFIED PRODUCTION SERVER.JS
// ====================================================================
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fetch from 'node-fetch';
import { v4 as uuidv4 } from 'uuid';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse incoming JSON payloads
app.use(express.json());

// Serve all your static frontend files (index.html, app.js, styles.css) 
// Make sure these frontend files sit in a folder named 'public'
app.use(express.static(path.join(__dirname, 'public')));

// --------------------------------------------------------------------
// 1. RAW MTN MOMO CORE ROUTING LOGIC
// --------------------------------------------------------------------
async function getMtnToken() {
    const auth = Buffer.from(`${process.env.MTN_API_USER}:${process.env.MTN_API_KEY}`).toString('base64');
    const response = await fetch('https://momodeveloper.mtn.com/collection/token/', {
        method: 'POST',
        headers: {
            'Authorization': `Basic ${auth}`,
            'Ocp-Apim-Subscription-Key': process.env.MTN_SUBSCRIPTION_KEY
        }
    });
    if (!response.ok) throw new Error('Failed to fetch MTN security bearer token');
    const data = await response.json();
    return data.access_token;
}

async function initiateMtnPayment(phoneNumber, amount) {
    const token = await getMtnToken();
    const transactionId = uuidv4();

    const response = await fetch('https://momodeveloper.mtn.com/collection/v1_0/requesttopay', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Ocp-Apim-Subscription-Key': process.env.MTN_SUBSCRIPTION_KEY,
            'X-Reference-Id': transactionId,
            'X-Target-Environment': 'production', // Switched to production live matrix
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            "amount": amount.toString(),
            "currency": "UGX",
            "externalId": `TXN-${Date.now()}`,
            "payer": { "partyIdType": "MSISDN", "partyId": phoneNumber },
            "payerMessage": "System Subscription Payment",
            "payeeNote": "Thank you for upgrading"
        })
    });

    return { success: response.status === 202, transactionId };
}

// --------------------------------------------------------------------
// 2. RAW AIRTEL MONEY CORE ROUTING LOGIC
// --------------------------------------------------------------------
async function getAirtelToken() {
    const response = await fetch('https://openapi.airtel.africa/auth/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            client_id: process.env.AIRTEL_CLIENT_ID,
            client_secret: process.env.AIRTEL_CLIENT_SECRET,
            grant_type: 'client_credentials'
        })
    });
    if (!response.ok) throw new Error('Failed to fetch Airtel security bearer token');
    const data = await response.json();
    return data.access_token;
}

async function initiateAirtelPayment(phoneNumber, amount) {
    const token = await getAirtelToken();
    const transactionId = `ART${Date.now()}`;
    const formattedNumber = phoneNumber.replace(/^\+?256/, ''); 

    const response = await fetch('https://openapi.airtel.africa/merchant/v1/payments/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Country': 'UG',
            'X-Currency': 'UGX',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
            "subscriber": { "msisdn": formattedNumber },
            "transaction": { "amount": Number(amount), "id": transactionId, "currency": "UGX" }
        })
    });

    const data = await response.json();
    return { success: response.status === 200 && data.status.success, transactionId };
}

// --------------------------------------------------------------------
// 3. COMBINED DEPLOYMENT GATEWAY CONTROL ENDPOINT
// --------------------------------------------------------------------
app.post('/api/initiate-payment', async (req, res) => {
    const { provider, phoneNumber, amount } = req.body;

    if (!phoneNumber || !amount) {
        return res.status(400).json({ success: false, error: 'Missing parameters' });
    }

    try {
        let paymentResult;
        if (provider.toUpperCase() === 'MTN') {
            paymentResult = await initiateMtnPayment(phoneNumber, amount);
        } else if (provider.toUpperCase() === 'AIRTEL') {
            paymentResult = await initiateAirtelPayment(phoneNumber, amount);
        } else {
            return res.status(400).json({ success: false, error: 'Unknown carrier string specification' });
        }

        if (paymentResult.success) {
            res.status(200).json({ success: true, txnId: paymentResult.transactionId });
        } else {
            res.status(500).json({ success: false, error: 'Network refused payment push payload initialization request' });
        }
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// Fallback safety route: serve index.html if navigating via standard web routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start listening for inbound global web user connection hooks
app.listen(PORT, () => {
    console.log(`🚀 Core Pipeline Active. Live listening initialized on server port: ${PORT}`);
});